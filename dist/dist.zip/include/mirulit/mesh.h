#ifndef MESH_H
#define MESH_H

#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

/* ==================== СТРУКТУРЫ ==================== */

/* Структура вершины (базовая) */
typedef struct {
    float position[3];    /* Позиция (x, y, z) */
    float normal[3];      /* Нормаль (x, y, z) */
    float texcoord[2];    /* Текстурные координаты (u, v) */
} Vertex;

/* Структура меша */
typedef struct {
    unsigned int VAO;          /* Vertex Array Object */
    unsigned int VBO;          /* Vertex Buffer Object */
    unsigned int EBO;          /* Element Buffer Object */
    
    Vertex* vertices;          /* Массив вершин */
    unsigned int* indices;     /* Массив индексов */
    
    unsigned int vertexCount;  /* Количество вершин */
    unsigned int indexCount;   /* Количество индексов */
    
    /* Материальные свойства */
    float color[4];            /* Цвет меша (RGBA) */
    float shininess;           /* Блеск (для освещения) */
} Mesh;

/* Структура трансформации */
typedef struct {
    float position[3];    /* Позиция (x, y, z) */
    float rotation[3];    /* Вращение (x, y, z в градусах) */
    float scale[3];       /* Масштаб (x, y, z) */
} Transform;

/* ==================== ПРОТОТИПЫ ФУНКЦИЙ ==================== */

/* Создание и уничтожение */
Mesh* mesh_create(void);
Mesh* mesh_create_from_data(Vertex* vertices, unsigned int vertexCount, 
                           unsigned int* indices, unsigned int indexCount);
Mesh* mesh_create_cube(float size);
Mesh* mesh_create_plane(float width, float height);
Mesh* mesh_create_sphere(float radius, unsigned int segments);
void mesh_destroy(Mesh* mesh);

/* Управление данными */
void mesh_set_vertices(Mesh* mesh, Vertex* vertices, unsigned int count);
void mesh_set_indices(Mesh* mesh, unsigned int* indices, unsigned int count);
void mesh_update_gpu(Mesh* mesh);

/* Отрисовка */
void mesh_draw(Mesh* mesh);
void mesh_draw_wireframe(Mesh* mesh);

/* Свойства */
void mesh_set_color(Mesh* mesh, float r, float g, float b, float a);
void mesh_set_shininess(Mesh* mesh, float shininess);

/* Утилиты */
void mesh_print_info(const Mesh* mesh);
void mesh_calculate_normals(Mesh* mesh);

/* Трансформации */
Transform* transform_create(void);
void transform_destroy(Transform* transform);
void transform_set_position(Transform* transform, float x, float y, float z);
void transform_set_rotation(Transform* transform, float x, float y, float z);
void transform_set_scale(Transform* transform, float x, float y, float z);
void transform_get_model_matrix(Transform* transform, float* matrix);

/* ==================== РЕАЛИЗАЦИЯ ==================== */

#ifdef MESH_IMPLEMENTATION

/* Создание пустого меша */
Mesh* mesh_create(void) {
    Mesh* mesh = (Mesh*)malloc(sizeof(Mesh));
    if (!mesh) {
        fprintf(stderr, "Failed to allocate memory for mesh\n");
        return NULL;
    }
    
    /* Инициализация значений по умолчанию */
    memset(mesh, 0, sizeof(Mesh));
    
    mesh->VAO = 0;
    mesh->VBO = 0;
    mesh->EBO = 0;
    mesh->vertices = NULL;
    mesh->indices = NULL;
    mesh->vertexCount = 0;
    mesh->indexCount = 0;
    
    /* Значения по умолчанию для цвета */
    mesh->color[0] = 0.8f;  /* R */
    mesh->color[1] = 0.8f;  /* G */
    mesh->color[2] = 0.8f;  /* B */
    mesh->color[3] = 1.0f;  /* A */
    
    mesh->shininess = 32.0f;
    
    /* Генерация OpenGL объектов */
    glGenVertexArrays(1, &mesh->VAO);
    glGenBuffers(1, &mesh->VBO);
    glGenBuffers(1, &mesh->EBO);
    
    return mesh;
}

/* Создание меша из данных */
Mesh* mesh_create_from_data(Vertex* vertices, unsigned int vertexCount, 
                           unsigned int* indices, unsigned int indexCount) {
    Mesh* mesh = mesh_create();
    if (!mesh) return NULL;
    
    mesh_set_vertices(mesh, vertices, vertexCount);
    if (indices && indexCount > 0) {
        mesh_set_indices(mesh, indices, indexCount);
    }
    
    mesh_update_gpu(mesh);
    return mesh;
}

/* Создание куба */
Mesh* mesh_create_cube(float size) {
    float halfSize = size / 2.0f;
    
    /* Вершины куба (8 вершин) */
    Vertex vertices[] = {
        /* Передняя грань */
        {{-halfSize, -halfSize,  halfSize}, {0.0f, 0.0f, 1.0f}, {0.0f, 0.0f}},
        {{ halfSize, -halfSize,  halfSize}, {0.0f, 0.0f, 1.0f}, {1.0f, 0.0f}},
        {{ halfSize,  halfSize,  halfSize}, {0.0f, 0.0f, 1.0f}, {1.0f, 1.0f}},
        {{-halfSize,  halfSize,  halfSize}, {0.0f, 0.0f, 1.0f}, {0.0f, 1.0f}},
        
        /* Задняя грань */
        {{-halfSize, -halfSize, -halfSize}, {0.0f, 0.0f, -1.0f}, {1.0f, 0.0f}},
        {{-halfSize,  halfSize, -halfSize}, {0.0f, 0.0f, -1.0f}, {1.0f, 1.0f}},
        {{ halfSize,  halfSize, -halfSize}, {0.0f, 0.0f, -1.0f}, {0.0f, 1.0f}},
        {{ halfSize, -halfSize, -halfSize}, {0.0f, 0.0f, -1.0f}, {0.0f, 0.0f}},
        
        /* Верхняя грань */
        {{-halfSize,  halfSize, -halfSize}, {0.0f, 1.0f, 0.0f}, {0.0f, 1.0f}},
        {{-halfSize,  halfSize,  halfSize}, {0.0f, 1.0f, 0.0f}, {0.0f, 0.0f}},
        {{ halfSize,  halfSize,  halfSize}, {0.0f, 1.0f, 0.0f}, {1.0f, 0.0f}},
        {{ halfSize,  halfSize, -halfSize}, {0.0f, 1.0f, 0.0f}, {1.0f, 1.0f}},
        
        /* Нижняя грань */
        {{-halfSize, -halfSize, -halfSize}, {0.0f, -1.0f, 0.0f}, {0.0f, 0.0f}},
        {{ halfSize, -halfSize, -halfSize}, {0.0f, -1.0f, 0.0f}, {1.0f, 0.0f}},
        {{ halfSize, -halfSize,  halfSize}, {0.0f, -1.0f, 0.0f}, {1.0f, 1.0f}},
        {{-halfSize, -halfSize,  halfSize}, {0.0f, -1.0f, 0.0f}, {0.0f, 1.0f}},
        
        /* Левая грань */
        {{-halfSize, -halfSize, -halfSize}, {-1.0f, 0.0f, 0.0f}, {0.0f, 0.0f}},
        {{-halfSize, -halfSize,  halfSize}, {-1.0f, 0.0f, 0.0f}, {1.0f, 0.0f}},
        {{-halfSize,  halfSize,  halfSize}, {-1.0f, 0.0f, 0.0f}, {1.0f, 1.0f}},
        {{-halfSize,  halfSize, -halfSize}, {-1.0f, 0.0f, 0.0f}, {0.0f, 1.0f}},
        
        /* Правая грань */
        {{ halfSize, -halfSize, -halfSize}, {1.0f, 0.0f, 0.0f}, {1.0f, 0.0f}},
        {{ halfSize,  halfSize, -halfSize}, {1.0f, 0.0f, 0.0f}, {1.0f, 1.0f}},
        {{ halfSize,  halfSize,  halfSize}, {1.0f, 0.0f, 0.0f}, {0.0f, 1.0f}},
        {{ halfSize, -halfSize,  halfSize}, {1.0f, 0.0f, 0.0f}, {0.0f, 0.0f}}
    };
    
    /* Индексы для 6 граней (12 треугольников) */
    unsigned int indices[] = {
        /* Передняя грань */
        0, 1, 2, 2, 3, 0,
        /* Задняя грань */
        4, 5, 6, 6, 7, 4,
        /* Верхняя грань */
        8, 9, 10, 10, 11, 8,
        /* Нижняя грань */
        12, 13, 14, 14, 15, 12,
        /* Левая грань */
        16, 17, 18, 18, 19, 16,
        /* Правая грань */
        20, 21, 22, 22, 23, 20
    };
    
    return mesh_create_from_data(vertices, 24, indices, 36);
}

/* Создание плоскости */
Mesh* mesh_create_plane(float width, float height) {
    float halfWidth = width / 2.0f;
    float halfHeight = height / 2.0f;
    
    Vertex vertices[] = {
        {{-halfWidth, 0.0f, -halfHeight}, {0.0f, 1.0f, 0.0f}, {0.0f, 0.0f}},
        {{ halfWidth, 0.0f, -halfHeight}, {0.0f, 1.0f, 0.0f}, {1.0f, 0.0f}},
        {{ halfWidth, 0.0f,  halfHeight}, {0.0f, 1.0f, 0.0f}, {1.0f, 1.0f}},
        {{-halfWidth, 0.0f,  halfHeight}, {0.0f, 1.0f, 0.0f}, {0.0f, 1.0f}}
    };
    
    unsigned int indices[] = {
        0, 1, 2, 2, 3, 0
    };
    
    return mesh_create_from_data(vertices, 4, indices, 6);
}

/* Установка вершин меша */
void mesh_set_vertices(Mesh* mesh, Vertex* vertices, unsigned int count) {
    if (!mesh || !vertices || count == 0) return;
    
    /* Освобождаем старые вершины */
    if (mesh->vertices) {
        free(mesh->vertices);
    }
    
    /* Выделяем память для новых вершин */
    mesh->vertices = (Vertex*)malloc(count * sizeof(Vertex));
    if (!mesh->vertices) {
        fprintf(stderr, "Failed to allocate memory for vertices\n");
        mesh->vertexCount = 0;
        return;
    }
    
    /* Копируем данные */
    memcpy(mesh->vertices, vertices, count * sizeof(Vertex));
    mesh->vertexCount = count;
}

/* Установка индексов меша */
void mesh_set_indices(Mesh* mesh, unsigned int* indices, unsigned int count) {
    if (!mesh || !indices || count == 0) return;
    
    /* Освобождаем старые индексы */
    if (mesh->indices) {
        free(mesh->indices);
    }
    
    /* Выделяем память для новых индексов */
    mesh->indices = (unsigned int*)malloc(count * sizeof(unsigned int));
    if (!mesh->indices) {
        fprintf(stderr, "Failed to allocate memory for indices\n");
        mesh->indexCount = 0;
        return;
    }
    
    /* Копируем данные */
    memcpy(mesh->indices, indices, count * sizeof(unsigned int));
    mesh->indexCount = count;
}

/* Обновление данных на GPU */
void mesh_update_gpu(Mesh* mesh) {
    if (!mesh || mesh->vertexCount == 0) return;
    
    glBindVertexArray(mesh->VAO);
    
    /* Копируем вершины в VBO */
    glBindBuffer(GL_ARRAY_BUFFER, mesh->VBO);
    glBufferData(GL_ARRAY_BUFFER, mesh->vertexCount * sizeof(Vertex), 
                 mesh->vertices, GL_STATIC_DRAW);
    
    /* Устанавливаем атрибуты вершин */
    /* Позиция (layout location = 0) */
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void*)0);
    glEnableVertexAttribArray(0);
    
    /* Нормаль (layout location = 1) */
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), 
                         (void*)offsetof(Vertex, normal));
    glEnableVertexAttribArray(1);
    
    /* Текстурные координаты (layout location = 2) */
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), 
                         (void*)offsetof(Vertex, texcoord));
    glEnableVertexAttribArray(2);
    
    /* Копируем индексы в EBO (если есть) */
    if (mesh->indexCount > 0 && mesh->indices) {
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh->EBO);
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, mesh->indexCount * sizeof(unsigned int),
                    mesh->indices, GL_STATIC_DRAW);
    }
    
    /* Отвязка буферов */
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);
}

/* Отрисовка меша */
void mesh_draw(Mesh* mesh) {
    if (!mesh || mesh->vertexCount == 0) return;
    
    glBindVertexArray(mesh->VAO);
    
    if (mesh->indexCount > 0) {
        /* Используем индексированную отрисовку */
        glDrawElements(GL_TRIANGLES, mesh->indexCount, GL_UNSIGNED_INT, 0);
    } else {
        /* Используем неиндексированную отрисовку */
        glDrawArrays(GL_TRIANGLES, 0, mesh->vertexCount);
    }
    
    glBindVertexArray(0);
}

/* Отрисовка меша в режиме каркаса */
void mesh_draw_wireframe(Mesh* mesh) {
    if (!mesh || mesh->vertexCount == 0) return;
    
    glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
    mesh_draw(mesh);
    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
}

/* Установка цвета меша */
void mesh_set_color(Mesh* mesh, float r, float g, float b, float a) {
    if (!mesh) return;
    
    mesh->color[0] = r;
    mesh->color[1] = g;
    mesh->color[2] = b;
    mesh->color[3] = a;
}

/* Установка блеска */
void mesh_set_shininess(Mesh* mesh, float shininess) {
    if (!mesh) return;
    
    mesh->shininess = shininess;
}

/* Вывод информации о меше */
void mesh_print_info(const Mesh* mesh) {
    if (!mesh) {
        printf("Mesh: NULL\n");
        return;
    }
    
    printf("=== Mesh Information ===\n");
    printf("Vertices: %u\n", mesh->vertexCount);
    printf("Indices: %u\n", mesh->indexCount);
    printf("VAO: %u\n", mesh->VAO);
    printf("VBO: %u\n", mesh->VBO);
    printf("EBO: %u\n", mesh->EBO);
    printf("Color: [%.2f, %.2f, %.2f, %.2f]\n", 
           mesh->color[0], mesh->color[1], mesh->color[2], mesh->color[3]);
    printf("Shininess: %.2f\n", mesh->shininess);
    printf("========================\n");
}

/* Уничтожение меша */
void mesh_destroy(Mesh* mesh) {
    if (!mesh) return;
    
    /* Освобождаем память на CPU */
    if (mesh->vertices) free(mesh->vertices);
    if (mesh->indices) free(mesh->indices);
    
    /* Удаляем OpenGL объекты */
    if (mesh->VAO) glDeleteVertexArrays(1, &mesh->VAO);
    if (mesh->VBO) glDeleteBuffers(1, &mesh->VBO);
    if (mesh->EBO) glDeleteBuffers(1, &mesh->EBO);
    
    free(mesh);
}

/* ==================== ТРАНСФОРМАЦИИ ==================== */

/* Создание трансформации */
Transform* transform_create(void) {
    Transform* transform = (Transform*)malloc(sizeof(Transform));
    if (!transform) return NULL;
    
    /* Инициализация значениями по умолчанию */
    transform->position[0] = 0.0f;
    transform->position[1] = 0.0f;
    transform->position[2] = 0.0f;
    
    transform->rotation[0] = 0.0f;
    transform->rotation[1] = 0.0f;
    transform->rotation[2] = 0.0f;
    
    transform->scale[0] = 1.0f;
    transform->scale[1] = 1.0f;
    transform->scale[2] = 1.0f;
    
    return transform;
}

/* Уничтожение трансформации */
void transform_destroy(Transform* transform) {
    if (transform) free(transform);
}

/* Установка позиции */
void transform_set_position(Transform* transform, float x, float y, float z) {
    if (!transform) return;
    
    transform->position[0] = x;
    transform->position[1] = y;
    transform->position[2] = z;
}

/* Установка вращения */
void transform_set_rotation(Transform* transform, float x, float y, float z) {
    if (!transform) return;
    
    transform->rotation[0] = x;
    transform->rotation[1] = y;
    transform->rotation[2] = z;
}

/* Установка масштаба */
void transform_set_scale(Transform* transform, float x, float y, float z) {
    if (!transform) return;
    
    transform->scale[0] = x;
    transform->scale[1] = y;
    transform->scale[2] = z;
}

/* Получение матрицы модели (упрощенная версия) */
void transform_get_model_matrix(Transform* transform, float* matrix) {
    if (!transform || !matrix) return;
    
    /* Инициализируем матрицу единичной */
    for (int i = 0; i < 16; i++) {
        matrix[i] = 0.0f;
    }
    matrix[0] = matrix[5] = matrix[10] = matrix[15] = 1.0f;
    
    /* Применяем масштаб */
    matrix[0] *= transform->scale[0];
    matrix[5] *= transform->scale[1];
    matrix[10] *= transform->scale[2];
    
    /* Применяем перемещение */
    matrix[12] = transform->position[0];
    matrix[13] = transform->position[1];
    matrix[14] = transform->position[2];
}

#endif /* MESH_IMPLEMENTATION */

#endif /* MESH_H */