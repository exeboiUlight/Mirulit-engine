#include <mirulit/window.h>
#include <mirulit/maths.h>
#define MESH_IMPLEMENTATION
#include <mirulit/mesh.h>
#include <stdio.h>
#include <math.h>

/* ========== ОБНОВЛЕННЫЕ ШЕЙДЕРЫ ========== */

/* Вершинный шейдер с поддержкой нормалей и трансформаций */
const char* vertexShaderSource = 
    "#version 330 core\n"
    "layout (location = 0) in vec3 aPos;\n"
    "layout (location = 1) in vec3 aNormal;\n"
    "layout (location = 2) in vec2 aTexCoord;\n"
    "uniform mat4 model;\n"
    "uniform mat4 view;\n"
    "uniform mat4 projection;\n"
    "out vec3 FragPos;\n"
    "out vec3 Normal;\n"
    "out vec2 TexCoord;\n"
    "void main()\n"
    "{\n"
    "    FragPos = vec3(model * vec4(aPos, 1.0));\n"
    "    Normal = mat3(transpose(inverse(model))) * aNormal;\n"
    "    TexCoord = aTexCoord;\n"
    "    gl_Position = projection * view * model * vec4(aPos, 1.0);\n"
    "}\0";

/* Фрагментный шейдер с освещением */
const char* fragmentShaderSource = 
    "#version 330 core\n"
    "in vec3 FragPos;\n"
    "in vec3 Normal;\n"
    "in vec2 TexCoord;\n"
    "out vec4 FragColor;\n"
    "uniform vec3 objectColor;\n"
    "uniform vec3 lightPos;\n"
    "uniform vec3 viewPos;\n"
    "uniform float shininess;\n"
    "void main()\n"
    "{\n"
    "    // Ambient\n"
    "    float ambientStrength = 0.1;\n"
    "    vec3 ambient = ambientStrength * vec3(1.0);\n"
    "    \n"
    "    // Diffuse\n"
    "    vec3 norm = normalize(Normal);\n"
    "    vec3 lightDir = normalize(lightPos - FragPos);\n"
    "    float diff = max(dot(norm, lightDir), 0.0);\n"
    "    vec3 diffuse = diff * vec3(1.0);\n"
    "    \n"
    "    // Specular\n"
    "    vec3 viewDir = normalize(viewPos - FragPos);\n"
    "    vec3 reflectDir = reflect(-lightDir, norm);\n"
    "    float spec = pow(max(dot(viewDir, reflectDir), 0.0), shininess);\n"
    "    vec3 specular = spec * vec3(0.5);\n"
    "    \n"
    "    // Result\n"
    "    vec3 result = (ambient + diffuse + specular) * objectColor;\n"
    "    FragColor = vec4(result, 1.0);\n"
    "}\0";

/* ========== ПЕРЕМЕННЫЕ ========== */
unsigned int shaderProgram;
Mesh* mesh = NULL;
Transform* transform = NULL;

/* Функция компиляции шейдера */
unsigned int compileShader(unsigned int type, const char* source) {
    unsigned int shader = glCreateShader(type);
    glShaderSource(shader, 1, &source, NULL);
    glCompileShader(shader);
    
    /* Проверка ошибок компиляции */
    int success;
    char infoLog[512];
    glGetShaderiv(shader, GL_COMPILE_STATUS, &success);
    if (!success) {
        glGetShaderInfoLog(shader, 512, NULL, infoLog);
        fprintf(stderr, "ERROR::SHADER::COMPILATION_FAILED\n%s\n", infoLog);
        glDeleteShader(shader);
        return 0;
    }
    
    return shader;
}

/* Функция создания шейдерной программы */
unsigned int createShaderProgram() {
    /* Компиляция вершинного шейдера */
    unsigned int vertexShader = compileShader(GL_VERTEX_SHADER, vertexShaderSource);
    if (vertexShader == 0) {
        return 0;
    }
    
    /* Компиляция фрагментного шейдера */
    unsigned int fragmentShader = compileShader(GL_FRAGMENT_SHADER, fragmentShaderSource);
    if (fragmentShader == 0) {
        glDeleteShader(vertexShader);
        return 0;
    }
    
    /* Создание шейдерной программы */
    unsigned int program = glCreateProgram();
    glAttachShader(program, vertexShader);
    glAttachShader(program, fragmentShader);
    glLinkProgram(program);
    
    /* Проверка ошибок линковки */
    int success;
    char infoLog[512];
    glGetProgramiv(program, GL_LINK_STATUS, &success);
    if (!success) {
        glGetProgramInfoLog(program, 512, NULL, infoLog);
        fprintf(stderr, "ERROR::PROGRAM::LINKING_FAILED\n%s\n", infoLog);
        glDeleteShader(vertexShader);
        glDeleteShader(fragmentShader);
        glDeleteProgram(program);
        return 0;
    }
    
    /* Удаление шейдеров после линковки */
    glDeleteShader(vertexShader);
    glDeleteShader(fragmentShader);
    
    return program;
}

/* Функция создания матрицы вращения вокруг оси Y (в радианах) */
void createRotationMatrixY(float angle, float* matrix) {
    float cosA = cosf(angle);
    float sinA = sinf(angle);
    
    /* Обнуляем матрицу */
    for (int i = 0; i < 16; i++) {
        matrix[i] = 0.0f;
    }
    
    /* Устанавливаем значения для вращения вокруг Y */
    matrix[0] = cosA;    /* X.X */
    matrix[2] = sinA;    /* X.Z */
    matrix[5] = 1.0f;    /* Y.Y */
    matrix[8] = -sinA;   /* Z.X */
    matrix[10] = cosA;   /* Z.Z */
    matrix[15] = 1.0f;   /* W.W */
}

/* Функция создания матрицы вращения вокруг оси X (в радианах) */
void createRotationMatrixX(float angle, float* matrix) {
    float cosA = cosf(angle);
    float sinA = sinf(angle);
    
    /* Обнуляем матрицу */
    for (int i = 0; i < 16; i++) {
        matrix[i] = 0.0f;
    }
    
    /* Устанавливаем значения для вращения вокруг X */
    matrix[0] = 1.0f;    /* X.X */
    matrix[5] = cosA;    /* Y.Y */
    matrix[6] = -sinA;   /* Y.Z */
    matrix[9] = sinA;    /* Z.Y */
    matrix[10] = cosA;   /* Z.Z */
    matrix[15] = 1.0f;   /* W.W */
}

/* Функция создания матрицы вращения вокруг оси Z (в радианах) */
void createRotationMatrixZ(float angle, float* matrix) {
    float cosA = cosf(angle);
    float sinA = sinf(angle);
    
    /* Обнуляем матрицу */
    for (int i = 0; i < 16; i++) {
        matrix[i] = 0.0f;
    }
    
    /* Устанавливаем значения для вращения вокруг Z */
    matrix[0] = cosA;    /* X.X */
    matrix[1] = -sinA;   /* X.Y */
    matrix[4] = sinA;    /* Y.X */
    matrix[5] = cosA;    /* Y.Y */
    matrix[10] = 1.0f;   /* Z.Z */
    matrix[15] = 1.0f;   /* W.W */
}

/* Функция умножения матриц 4x4 */
void multiplyMatrices(float* result, float* a, float* b) {
    float temp[16];
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            temp[i*4 + j] = 0.0f;
            for (int k = 0; k < 4; k++) {
                temp[i*4 + j] += a[i*4 + k] * b[k*4 + j];
            }
        }
    }
    memcpy(result, temp, 16 * sizeof(float));
}

/* Улучшенная функция получения матрицы модели с вращением */
void transform_get_model_matrix_improved(Transform* transform, float* matrix) {
    if (!transform || !matrix) return;
    
    float scaleMatrix[16];
    float rotationXMatrix[16];
    float rotationYMatrix[16];
    float rotationZMatrix[16];
    float translationMatrix[16];
    float tempMatrix1[16];
    float tempMatrix2[16];
    
    /* 1. Масштабирование */
    for (int i = 0; i < 16; i++) scaleMatrix[i] = 0.0f;
    scaleMatrix[0] = transform->scale[0];
    scaleMatrix[5] = transform->scale[1];
    scaleMatrix[10] = transform->scale[2];
    scaleMatrix[15] = 1.0f;
    
    /* 2. Вращение (в радианах) */
    float rx = transform->rotation[0] * 3.14159265f / 180.0f;
    float ry = transform->rotation[1] * 3.14159265f / 180.0f;
    float rz = transform->rotation[2] * 3.14159265f / 180.0f;
    
    createRotationMatrixX(rx, rotationXMatrix);
    createRotationMatrixY(ry, rotationYMatrix);
    createRotationMatrixZ(rz, rotationZMatrix);
    
    /* 3. Перемещение */
    for (int i = 0; i < 16; i++) translationMatrix[i] = 0.0f;
    translationMatrix[0] = 1.0f;
    translationMatrix[5] = 1.0f;
    translationMatrix[10] = 1.0f;
    translationMatrix[15] = 1.0f;
    translationMatrix[12] = transform->position[0];
    translationMatrix[13] = transform->position[1];
    translationMatrix[14] = transform->position[2];
    
    /* Порядок: Масштаб → Вращение → Перемещение */
    /* rotationZ * rotationY * rotationX */
    multiplyMatrices(tempMatrix1, rotationYMatrix, rotationXMatrix);
    multiplyMatrices(tempMatrix2, rotationZMatrix, tempMatrix1);
    
    /* tempMatrix2 * scaleMatrix */
    multiplyMatrices(tempMatrix1, tempMatrix2, scaleMatrix);
    
    /* translationMatrix * (rotation * scale) */
    multiplyMatrices(matrix, translationMatrix, tempMatrix1);
}

int main(void) {
    /* Инициализация окна */
    if (!window_init(800, 600, "3D Вращение")) {
        return -1;
    }
    
    /* Настройка параметров окна */
    window_set_vsync(true);
    window_set_background_color(0.1f, 0.1f, 0.2f, 1.0f);  /* Темно-синий фон */
    
    /* Создание шейдерной программы */
    shaderProgram = createShaderProgram();
    if (shaderProgram == 0) {
        window_terminate();
        return -1;
    }
    
    /* ВЫБЕРИТЕ ЧТО ВЫ ХОТИТЕ: КУБ ИЛИ КВАДРАТ (ПЛОСКОСТЬ) */
    int objectType = 1;  /* 1 - куб, 2 - квадрат */
    
    if (objectType == 1) {
        /* Создание меша (куба) */
        mesh = mesh_create_cube(1.0f);
        if (!mesh) {
            fprintf(stderr, "Failed to create cube mesh\n");
            glDeleteProgram(shaderProgram);
            window_terminate();
            return -1;
        }
        
        /* Настройка цвета куба */
        mesh_set_color(mesh, 0.8f, 0.3f, 0.2f, 1.0f);  /* Оранжево-красный */
        mesh_set_shininess(mesh, 64.0f);
    } else {
        /* Создание меша (квадрата/плоскости) */
        mesh = mesh_create_plane(2.0f, 2.0f);
        if (!mesh) {
            fprintf(stderr, "Failed to create plane mesh\n");
            glDeleteProgram(shaderProgram);
            window_terminate();
            return -1;
        }
        
        /* Настройка цвета квадрата */
        mesh_set_color(mesh, 0.2f, 0.8f, 0.3f, 1.0f);  /* Зеленый */
        mesh_set_shininess(mesh, 32.0f);
    }
    
    /* Создание трансформации */
    transform = transform_create();
    if (transform) {
        if (objectType == 1) {
            transform_set_position(transform, 0.0f, 0.0f, -5.0f);  /* Кубик дальше */
        } else {
            transform_set_position(transform, 0.0f, 0.0f, -3.0f);  /* Квадрат ближе */
        }
        transform_set_rotation(transform, 0.0f, 0.0f, 0.0f);
        transform_set_scale(transform, 1.0f, 1.0f, 1.0f);
    }
    
    /* Вывод информации */
    window_print_info();
    mesh_print_info(mesh);
    printf("\n=== УПРАВЛЕНИЕ ===\n");
    printf("Объект: %s\n", objectType == 1 ? "КУБ" : "КВАДРАТ");
    printf("Вращение: Автоматическое по трем осям\n");
    printf("========================\n");
    
    /* Основные uniform-переменные */
    float modelMatrix[16];
    
    /* Матрица вида (камера) */
    float viewMatrix[16] = {
        1.0f, 0.0f, 0.0f, 0.0f,
        0.0f, 1.0f, 0.0f, 0.0f,
        0.0f, 0.0f, 1.0f, 0.0f,
        0.0f, 0.0f, 0.0f, 1.0f
    };
    
    /* Матрица проекции */
    float aspect = window_get_aspect_ratio();
    float fov = 45.0f * 3.14159265f / 180.0f;  /* 45 градусов в радианах */
    float near = 0.1f;
    float far = 100.0f;
    
    float projectionMatrix[16] = {0};
    float tanHalfFov = tanf(fov / 2.0f);
    
    projectionMatrix[0] = 1.0f / (aspect * tanHalfFov);
    projectionMatrix[5] = 1.0f / tanHalfFov;
    projectionMatrix[10] = -(far + near) / (far - near);
    projectionMatrix[11] = -1.0f;
    projectionMatrix[14] = -(2.0f * far * near) / (far - near);
    
    /* Включение теста глубины */
    glEnable(GL_DEPTH_TEST);
    
    /* Переменные для вращения */
    float rotationX = 0.0f;
    float rotationY = 0.0f;
    float rotationZ = 0.0f;
    
    float rotationSpeedX = 0.5f;  /* Скорость вращения по оси X (градусов/кадр) */
    float rotationSpeedY = 0.7f;  /* Скорость вращения по оси Y */
    float rotationSpeedZ = 0.3f;  /* Скорость вращения по оси Z */
    
    /* Основной цикл */
    while (!window_should_close()) {
        /* Обработка ввода */
        window_process_input();
        
        /* Очистка буферов */
        window_clear();
        
        /* Обновление вращения */
        rotationX += rotationSpeedX;
        rotationY += rotationSpeedY;
        rotationZ += rotationSpeedZ;
        
        /* Ограничение углов до 360 градусов */
        if (rotationX > 360.0f) rotationX -= 360.0f;
        if (rotationY > 360.0f) rotationY -= 360.0f;
        if (rotationZ > 360.0f) rotationZ -= 360.0f;
        
        /* Применение вращения к трансформации */
        if (transform) {
            transform_set_rotation(transform, rotationX, rotationY, rotationZ);
            
            /* Получение улучшенной матрицы модели с правильным вращением */
            transform_get_model_matrix_improved(transform, modelMatrix);
        }
        
        /* Использование шейдерной программы */
        glUseProgram(shaderProgram);
        
        /* Установка uniform-переменных */
        if (transform) {
            /* Передача матриц в шейдер */
            glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "model"), 1, GL_FALSE, modelMatrix);
            glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "view"), 1, GL_FALSE, viewMatrix);
            glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "projection"), 1, GL_FALSE, projectionMatrix);
            
            /* Передача цвета и параметров освещения */
            glUniform3f(glGetUniformLocation(shaderProgram, "objectColor"), 
                       mesh->color[0], mesh->color[1], mesh->color[2]);
            
            /* Динамическое изменение позиции света для интересного эффекта */
            float lightX = 3.0f * sinf(rotationY * 3.14159265f / 180.0f);
            float lightY = 3.0f * cosf(rotationX * 3.14159265f / 180.0f);
            float lightZ = 3.0f;
            
            glUniform3f(glGetUniformLocation(shaderProgram, "lightPos"), 
                       lightX, lightY, lightZ);
            glUniform3f(glGetUniformLocation(shaderProgram, "viewPos"), 0.0f, 0.0f, 0.0f);
            glUniform1f(glGetUniformLocation(shaderProgram, "shininess"), mesh->shininess);
        }
        
        /* Отрисовка меша */
        mesh_draw(mesh);
        
        /* Дополнительная отрисовка в режиме каркаса (опционально) */
        glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
        glLineWidth(1.0f);
        mesh_set_color(mesh, 0.1f, 0.1f, 0.1f, 1.0f);  /* Темный цвет для каркаса */
        glUniform3f(glGetUniformLocation(shaderProgram, "objectColor"), 
                   0.1f, 0.1f, 0.1f);
        mesh_draw(mesh);
        glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
        
        /* Восстанавливаем цвет объекта */
        if (objectType == 1) {
            mesh_set_color(mesh, 0.8f, 0.3f, 0.2f, 1.0f);
        } else {
            mesh_set_color(mesh, 0.2f, 0.8f, 0.3f, 1.0f);
        }
        
        /* Обмен буферов и обработка событий */
        window_swap_buffers();
        window_poll_events();
    }
    
    /* Очистка ресурсов */
    if (mesh) mesh_destroy(mesh);
    if (transform) transform_destroy(transform);
    glDeleteProgram(shaderProgram);
    
    /* Завершение работы */
    window_terminate();
    
    return 0;
}